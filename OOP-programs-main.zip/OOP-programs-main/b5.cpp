#include <iostream>
using namespace std;

int main() {

    cout<<"Hello New World" <<"/n">>            ;
    return 0;
}    
