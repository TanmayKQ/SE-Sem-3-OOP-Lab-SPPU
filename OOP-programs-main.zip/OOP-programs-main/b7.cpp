
#include <iostream>
using namespace std;

int main(){
     cout<< "size of char:"sizeof(char);
     cout<<"size of int:"sizeof(int);
     cout<<"size of float:"sizeof(float);
}






