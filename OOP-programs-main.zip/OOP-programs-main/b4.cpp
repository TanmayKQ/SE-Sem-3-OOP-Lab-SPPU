
#include <iostream>

using namespace std;
int main()
{
	
	int a=10,b=20,c;
	cout<<" Hello\n";
	c=a+b;
	cout<<"The addition of a and b is "<<c<<"\n";
	return 0;
}
