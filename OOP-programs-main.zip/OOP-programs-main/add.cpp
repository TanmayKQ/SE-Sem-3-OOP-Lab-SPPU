#mathematical oprations (add)
#include<iostream>
using namespace std;
int main(){
int a,b;
a=10;
b=20;
c=a+b;
cout<<c>>
}




