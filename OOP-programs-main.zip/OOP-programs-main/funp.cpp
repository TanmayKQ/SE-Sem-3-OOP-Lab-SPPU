#include <iostream>
using namespace std;
void sum(int,int);

int main(){
    int a,b;
    cout<<"Enter the values for a and b ";
    cin>>a>>b;
    sum(a,b);
    return 0;
}
void sum(int m, int n){
     int c=m+n;
     cout<<"the sum is"<<c;
}

    
    

    
    
    
