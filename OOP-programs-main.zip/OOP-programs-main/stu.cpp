#include <iostream>
using namespace std;

class Student
{     public:
          int age;
          int roll;
          float height;
          string name;
          
};

int main(){
       Student p;
       cout<<"Enter the name of student:";
       cin>>p.name;
       cout<<"age of stu";
       cin>>p.age;
       cout<<"roll no.";
       cin>>p.roll;
       cout<<"height is";
       cin>>p.height;
       return 0;
       }
       
          


